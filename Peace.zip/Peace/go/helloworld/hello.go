package main

import (
	"fmt"
	"log"
	"myFmt"

	"github.com/golang/example/stringutil"
)

func main() {	
	fmt.Println("Hello World")
	myFmt.Println(stringutil.Reverse("Hello World"))
	log.Println("I am here")
}
