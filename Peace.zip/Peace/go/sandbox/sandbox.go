package main

import (
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"hr"
	htmlTemplate "html/template"
	"io/ioutil"
	"log"
	"math"
	"net/http"
	"os"
	"reflect"
	"sort"
	"strconv"
	"strings"
	"text/template"
	"time"
	"unicode"
	"unicode/utf8"
	"weight"
)

const dbReady = false
const balance = 200
const numberLimitRetry = 2

var data = `
[
  {
    "userId": 1,
    "id": 1,
    "title": "delectus aut autem",
    "completed": false
  },
  {
    "userId": 1,
    "id": 2,
    "title": "quis ut nam facilis et officia qui",
    "completed": false
  },
  {
    "userId": 1,
    "id": 3
  }
  ]
`
var episodeMap = map[string]int{
	"i":   1,
	"ii":  2,
	"iii": 3,
	"iv":  4,
	"v":   5,
}
var movieName = flag.String("name", "anonymous", "Your movie name")
var movieEpisode = flagMovieEpisode()

type KG float64
type LB float64
type Peice int
type Person struct {
	Name    string
	Surname string
	Age     int
}
type Employee struct {
	Person
	Position string
}
type KbankEmployee struct { // anonymous field
	Person
	position string
}
type Programmer struct {
	Employee
	Languages []string
}
type Tester struct {
	Employee
	Tools []string
}
type BinaryTree struct {
	value       int
	left, right *BinaryTree
}
type Todo struct {
	UserId int    `json:"userId"`
	Id     int    `json:"id"`
	Title  string `json:"title,omitempty"`
	// Completed bool   `json:"completed"`
	Completed *bool `json:"completed,omitempty"`
}
type Geo struct {
	Lat string `json:"lat"`
	Lng string `json:"lng"`
}
type Address struct {
	Street  string `json:"street"`
	Suite   string `json:"suite"`
	City    string `json:"city"`
	Zipcode string `json:"zipcode"`
	Geo     Geo    `json:"geo"`
}
type Company struct {
	Name        string `json:"name"`
	CatchPhrase string `json:"catchPhrase"`
	Bs          string `json:"bs"`
}
type User []struct {
	ID       int     `json:"id"`
	Name     string  `json:"name"`
	Username string  `json:"username"`
	Email    string  `json:"email"`
	Address  Address `json:"address"`
	Phone    string  `json:"phone"`
	Website  string  `json:"website"`
	Company  Company `json:"company"`
}
type Point struct {
	X, Y float64
}
type NoteBook struct {
	content []byte
}
type Sword struct {
	name string
}
type Bow struct {
	name string
}
type Item interface {
	cost() int
}
type Weapon interface {
	detail() string
	Item
}
type RomanEpisode struct {
	episode string
}
type byName []*Person
type customSort struct {
	Persons []*Person
	less    func(i, j *Person) bool
}

func (p byName) Len() int {
	return len(p)
}
func (p byName) Less(i, j int) bool {
	return p[i].Name < p[j].Name
}
func (p byName) Swap(i, j int) {
	p[i], p[j] = p[j], p[i]
}
func (c customSort) Len() int {
	return len(c.Persons)
}
func (c customSort) Less(i, j int) bool {
	return c.less(c.Persons[i], c.Persons[j])
}
func (c customSort) Swap(i, j int) {
	c.Persons[i], c.Persons[j] = c.Persons[j], c.Persons[i]
}
func (r *RomanEpisode) String() string {
	return strconv.Itoa(episodeMap[r.episode])
}
func (r *RomanEpisode) Set(value string) error {
	r.episode = value
	return nil
}
func flagMovieEpisode() *RomanEpisode {
	romanEpisode := RomanEpisode{}
	flag.Var(&romanEpisode, "episode", "Your movie episode")
	return &romanEpisode
}
func attack(w Weapon) {
	fmt.Printf("attack by: %s. Item cost: %d\n", w.detail(), w.cost())
}
func (b Bow) detail() string {
	return "Magic of Runa Bow"
}
func (b Bow) cost() int {
	return 100
}
func (s Sword) detail() string {
	return "Magic of Kantana Sword"
}
func (s Sword) cost() int {
	return 120
}
func (nb *NoteBook) Write(p []byte) (n int, err error) {
	nb.content = append(nb.content, p...)
	return len(p), nil
}
func (p *Person) FullName() string {
	return p.Name + " " + p.Surname
}
func (e *Employee) Detail() string {
	return "FullName: " + e.FullName() + ", Age: " + strconv.Itoa(e.Age) + ", Position: " + e.Position
}
func (e *Employee) IsSamePosition(other *Employee) bool {
	return e.Position == other.Position
}
func (p *Programmer) Detail() string {
	return p.Employee.Detail() + ", Languages: " + strings.Join(p.Languages, ", ")
}
func (t *Tester) Detail() string {
	return t.Employee.Detail() + ", Tools: " + strings.Join(t.Tools, ", ")
}
func (p *Point) Length() float64 {
	return math.Hypot(p.X, p.Y)
}
func (p *Point) MoveXTo(newX float64) {
	p.X = newX
}
func (p *Point) MoveYTo(newY float64) {
	p.Y = newY
}
func (lb LB) toKG() KG {
	return KG(lb / 2.204)
}
func (kg KG) toLB() LB {
	return LB(kg * 2.204)
}
func (kg KG) toString() string {
	s := fmt.Sprintf("%v", kg)
	return s + " kg."
}
func (lb LB) toString() string {
	s := fmt.Sprintf("%v", lb)
	return s + " lbs."
}
func (b *BinaryTree) sum() int {
	if b == nil {
		return 0
	}
	return b.value + b.left.sum() + b.right.sum()
}
func showDF(node *BinaryTree) {
	if node != nil {
		showDF(node.left)
		fmt.Println(node.value)
		showDF(node.right)
	}
}
func upperCase(s string) string {
	return strings.ToUpper(s)
}
func connectDatabase(numRetry int) error {
	if numRetry == numberLimitRetry {
		return nil
	}
	return errors.New("busy")
}
func waitForDatabase() error {
	timeout := 3 * time.Second
	deadline := time.Now().Add(timeout)
	for tries := 0; time.Now().Before(deadline); tries++ {
		err := connectDatabase(tries)
		if err == nil {
			return nil
		}
		log.Printf("Database is not responding (%v), retrying...", err)
		time.Sleep(time.Second)
	}
	return fmt.Errorf("waitForDatabase: timeout %v", timeout)
}
func getBalance() (int, error) {
	if !dbReady {
		if err := waitForDatabase(); err != nil {
			return 0, fmt.Errorf("getBalance: %v: ", err)
		}
	}
	return balance, nil
}
func withdraw(amount int) (int, error) {
	balance, err := getBalance()
	if err != nil {
		return 0, fmt.Errorf("withdraw: %v", err)
	}
	if amount > balance {
		return 0, errors.New("insufficient fund")
	}
	return amount, nil
}
func add(a, b float64) float64 {
	return a + b
}
func sub(a, b float64) float64 {
	return a - b
}
func apply(a, b float64, opt func(float64, float64) float64) (float64, error) {
	if opt == nil {
		return math.NaN(), fmt.Errorf("apply: nil operation")
	}
	return opt(a, b), nil
}
func anonymousFunc() func() int {
	var x = 0
	return func() int {
		x++
		return x
	}
}
func anonymousFuncList(list []int) []func() {
	ret := []func(){}
	for _, v := range list {
		captureVal := v // create capture var because prevent key/value have run to end of slice
		ret = append(ret, func() {
			fmt.Println(captureVal)
		})
	}
	return ret
}
func createFib() func(int) []int {
	fibList := []int{0, 1, 1, 2, 3, 5}
	return func(n int) []int {
		// fmt.Println("size of fibList: ", len(fibList))
		for n > len(fibList) {
			lastIndex := len(fibList) - 1
			fibList = append(fibList, fibList[lastIndex]+fibList[lastIndex-1])
		}
		return fibList[:n]
	}
}
func profileTime(fibFunc func(int) []int) func(int) []int {
	return func(n int) []int {
		start := time.Now()
		result := fibFunc(n)
		log.Printf("call with %d tooks %d ns", n, time.Now().Sub(start))
		return result
	}
}
func printEachLine(a ...interface{}) {
	for _, v := range a {
		fmt.Println(v)
	}
}
func stopWatch(name string) func() {
	start := time.Now()
	return func() {
		fmt.Printf("function %s: tooks time %v\n", name, time.Now().Sub(start).Seconds())
	}
}
func loadingImage() {
	defer stopWatch("loadingImage")()
	time.Sleep(2000 * time.Millisecond)
	fmt.Println("loadingImage: done")
}
func A(x int) {
	defer func() {
		fmt.Println("defer in A")
	}()
	B(x)
	fmt.Println("Hello in A")
}
func B(x int) {
	defer func() {
		fmt.Println("defer in B")
	}()
	C(x)
	fmt.Println("Hello in B")
}
func C(x int) {
	defer func() {
		fmt.Println("defer in C")
		if p := recover(); p != nil {
			fmt.Println("handling panic: ", p)
		}
	}()
	if x == 4 {
		panic("for no reason")
	}
}

func main() {
	k := KG(1)
	l := LB(2.204)
	l = 4.408
	// z := 3

	x := 1
	var p *int
	p = &x
	// var a, b, c int
	fmt.Println("&x", &x)
	fmt.Println("*(&x)", *(&x))
	fmt.Println("p", p)
	fmt.Println("*p", *p)
	// fmt.Printf("%#v %T", p, p)

	fmt.Println("k == 3", k == 3)
	fmt.Println("KG compare LB", k == l.toKG())
	fmt.Println(k.toString())
	fmt.Println(l.toString())

	if v := "1 kg."; v == k.toString() {
		fmt.Println("equal 1 kg.")
	}

	swh := "a"
	switch {
	case swh == "a":
		fmt.Println("A")
		fallthrough
	case swh == "b":
		fmt.Println("B")
	case swh == "c":
		fmt.Println("C")
	default:
		fmt.Println("Not match")
	}

	newK := weight.KG(1.5)
	fmt.Println(weight.KgToLb(newK))

	str := "hi-สวัสดี"
	fmt.Println(str)
	fmt.Println(len(str))
	fmt.Println("Ex.1: integer -> string")
	fmt.Println(string(104))
	fmt.Println("Ex.2: []byte (slice of byte) -> string")
	ex2 := []byte{0x68, 0x69, 0x2d, 0xe0, 0xb8, 0xaa, 0xe0, 0xb8, 0xa7, 0xe0, 0xb8, 0xb1, 0xe0, 0xb8, 0xaa, 0xe0, 0xb8, 0x94, 0xe0, 0xb8, 0xb5}
	fmt.Println(len(ex2))
	fmt.Println(string(ex2))
	fmt.Println("Ex.3: []rune (slice of rune) -> string")
	ex3 := []rune{0x68, 0x69, 0x2d, 0xe2a, 0xe27, 0xe31, 0xe2a, 0xe14, 0xe35}
	fmt.Println(len(ex3))
	fmt.Println(string(ex3))
	fmt.Println("Ex.4: string -> []byte (slice of byte)")
	ex4 := []byte(str)
	fmt.Println(len(ex4))
	fmt.Println(ex4)
	fmt.Println("Ex.5: string -> []rune (slice of rune)")
	ex5 := []rune(str)
	fmt.Println(len(ex5))
	fmt.Println(ex5)

	for i, v := range str {
		fmt.Printf("%d 0x%x %c\n", i, v, v)
	}
	fmt.Println(utf8.RuneCountInString(str))
	for i := 0; i < len(str); {
		r, s := utf8.DecodeRuneInString(str[i:])
		i += s
		fmt.Printf("%c, ", r)
	}

	fmt.Println()
	finder := "ส"
	fmt.Println(strings.Count(str, finder))
	// buff := bytes.Buffer{}
	buff := strings.Builder{}
	buff.WriteRune('y')
	buff.WriteRune('o')
	fmt.Println(buff.String())
	// strconv
	atoi, _ := strconv.Atoi("123")
	itoa := strconv.Itoa(123)
	fmt.Println(atoi, reflect.TypeOf(atoi))
	fmt.Println(itoa, reflect.TypeOf(itoa))

	fmt.Println(strconv.ParseBool("True"))
	fmt.Println(strconv.ParseBool("0"))
	fmt.Println(strconv.ParseBool("faLse"))
	// unicode
	fmt.Println("unicode.IsDigit('1') ", unicode.IsDigit('0'))
	fmt.Println("unicode.IsDigit('๒') ", unicode.IsDigit('๒'))
	fmt.Println("unicode.IsNumber('♛') ", unicode.IsNumber('♛'))
	fmt.Println("unicode.IsUpper('a') ", unicode.IsUpper('a'))
	fmt.Println("unicode.In('ก', unicode.Thai) ", unicode.In('ก', unicode.Thai))
	// untyped constant
	const persons = 4
	toffee := Peice(5) / persons
	cost := 2.01 / persons
	fmt.Println(toffee, reflect.TypeOf(toffee))
	fmt.Println(cost, reflect.TypeOf(cost))
	// group constant & iota
	const (
		sunday = iota + 1.1 // constant generator
		monday
		tuesday
		wednesday
		thursday = iota + 99
		friday
		saturday
	)
	fmt.Println(sunday, monday, tuesday, wednesday, thursday, friday, saturday)
	// array
	fruits := [4]string{
		"mango",
		"banana",
		"orange",
		"apple",
	}
	fmt.Println(len(fruits), fruits)
	newFruits := [...]string{
		3: "mango",
		"banana",
		1: "orange",
		0: "apple",
	}
	fmt.Println(len(newFruits), newFruits)
	fmt.Println(len(fruits), fruits)
	fmt.Println("fruits\t", reflect.TypeOf(fruits))
	fmt.Println("newFruits\t", reflect.TypeOf(newFruits))
	fmt.Println([2]int{1, 2} == [2]int{1, 2})
	fmt.Println([3]int{1, 2, 3} == [3]int{1, 3, 2})
	fmt.Println([2][3]int{{1, 2, 3}, {3, 4, 5}})
	// slices
	fruitsFavor := fruits[1:3] // [:] -> all index, [:len(x)] -> index 0 to len(x)-1
	fmt.Println(len(fruitsFavor), cap(fruitsFavor), fruitsFavor)
	myFavorite := fruitsFavor
	myFavorite[0] = "guava"
	fmt.Println(len(myFavorite), cap(myFavorite), myFavorite)
	fmt.Println(len(fruitsFavor), cap(fruitsFavor), fruitsFavor)
	fmt.Println(len(fruits), fruits)

	// sl := [10]int{}
	sl := make([]int, 0, 10)
	sl1 := sl[0:5]
	sl2 := sl[5:7]
	for i := range sl1 {
		sl1[i] = i * i
	}
	sl2[0] = 98
	sl2[1] = 99
	sl1 = append(sl1, sl2...) // append(sl1, sl2[0], sl2[1])
	sl1[len(sl1)-1] = 100
	sl1 = append(sl1, 71, 72, 73, 74) // append(sl1, 71, 72, 73)
	fmt.Println("sl:\t", sl)
	fmt.Println("sl1:\t", sl1, len(sl1), cap(sl1))
	fmt.Println("sl2:\t", sl2, len(sl2), cap(sl2))
	// map
	items := map[string]int{
		"pen":    4,
		"pencil": 5,
	}
	orders := make(map[string]int)
	orders["pen"] = 21
	orders["pencil"] = 23
	newItems := items
	newItems["ruler"] = 6
	newItems = orders
	fmt.Println("items:\t\t", items)
	fmt.Println("newItems:\t", newItems)
	fmt.Println("items[\"pen\"]:\t", items["pen"])
	fmt.Println("orders:\t\t", orders)

	delete(items, "pen")
	fmt.Println("items:\t\t", items)

	v, ok := items["ruler"]
	if !ok {
		fmt.Println("Not exist - ", v)
	} else {
		fmt.Println("Exist - ", v)
	}

	for v, k := range items {
		fmt.Println("key: ", k, ", value: ", v)
	}
	// struct
	st := struct {
		name string
		age  int
	}{"Peace", 33}
	fmt.Println(st)
	fmt.Println(st.name)

	p1 := Person{"Peace", "Srabour", 33}
	p2 := Person{Age: 33}
	p3 := new(Person)
	p3.Name = "Jugg"
	*p3 = Person{"Nusita", "Tanphan", 32}
	fmt.Println("p1 ->", p1)
	fmt.Println("p2 ->", p2)
	fmt.Printf("p3 (address) -> %+v\n", p3)
	fmt.Printf("p3 (value) -> %+v\n", *p3)

	e1 := Employee{
		Person:   Person{"Supakorn", "Srabour", 33},
		Position: "Programmer",
	}
	fmt.Printf("e1 -> %+v\n", e1)
	fmt.Println("e1.person.Name ->", e1.Person.Name)
	e2 := KbankEmployee{
		Person{Name: "Peat"},
		"Engineer",
	}
	fmt.Printf("e2 -> %+v\n", e2)
	fmt.Println("e2.Name ->", e2.Name) // or e2.Person.Name
	fmt.Println("e2.position ->", e2.position)

	emp := hr.AisEmployee{
		Person:   hr.Person{Name: "Peat AIS", Age: 33},
		Position: "Engineer",
	}
	fmt.Printf("emp -> %+v\n", emp)
	fmt.Println("emp.Name ->", emp.Name) // or emp.Person.Name
	fmt.Println("emp.Position ->", emp.Position)

	root := BinaryTree{value: 2}
	left := BinaryTree{value: 1}
	right := BinaryTree{value: 3}
	root.left = &left
	root.right = &right
	showDF(&root)
	// json marshal
	js := []Todo{}
	vjs := &js
	fmt.Printf("json marshal: %+v\n", js)
	json.Unmarshal([]byte(data), vjs)
	fmt.Printf("json marshal: %+v, len: %d\n", js, len(js))
	completed := true
	js[0].Completed = &completed
	// js[0].Completed = true

	ret, err := json.MarshalIndent(js, "", "  ")
	if err != nil {
		return
	}
	fmt.Println(string(ret))

	resp, err := http.Get("https://jsonplaceholder.typicode.com/users")
	// resp, err := http.Get("https://jsonplaceholder.typicode.com/todos")
	if err != nil {
		return
	}
	body, err := ioutil.ReadAll(resp.Body)
	resp.Body.Close()
	if err != nil {
		return
	}
	dataStruct := User{} // dataStruct := []Todo{}
	vjson := &dataStruct
	json.Unmarshal(body, vjson)
	fmt.Printf("json marshal, len: %d\n", len(dataStruct))
	result, err := json.MarshalIndent(dataStruct, "", "  ")
	if err != nil {
		return
	}
	fmt.Println(string(result))

	// json.Decode --> dataStruct
	resp, err = http.Get("https://jsonplaceholder.typicode.com/users")
	jsonDecoder := json.NewDecoder(resp.Body)
	dataStruct = User{}
	jsonDecoder.Decode(&dataStruct)
	resp.Body.Close()
	fmt.Printf("json marshal decoder, len: %d\n", len(dataStruct))
	// dataStruct --> std.Output
	jsonEncoder := json.NewEncoder(os.Stdout)
	jsonEncoder.Encode(dataStruct)
	// text template
	filicity := Person{"Filicity", "White", 33}
	oliver := Person{"Oliver", "Black", 30}
	people := []Person{filicity, oliver}

	const greetPerson = `Hi, I am {{.Name | upperCase}}. years old {{.Age}}{{"\n"}}`
	const greetPeople = `{{range .}}Hi, I am {{.Name}}. years old {{.Age}}{{"\n"}}{{end}}`
	maps := make(template.FuncMap)
	maps["upperCase"] = upperCase

	greetTemplate := template.Must(template.New("greetingFromPerson").
		// Funcs(template.FuncMap{"upperCase": upperCase}).
		Funcs(maps).
		Parse(greetPerson))
	greetPeopleTemplate := template.Must(template.New("greetingFromPeople").Parse(greetPeople))

	fmt.Println(greetTemplate.Name())
	greetTemplate.Execute(os.Stdout, filicity)
	greetTemplate.Execute(os.Stdout, oliver)
	fmt.Println("================================")
	greetPeopleTemplate.Execute(os.Stdout, people)
	// html template
	resp, err = http.Get("https://jsonplaceholder.typicode.com/todos")
	// file, err := ioutil.ReadFile("D:/Go_Workspace/src/sandbox/index.html")
	if err != nil {
		return
	}
	jsonDecoder = json.NewDecoder(resp.Body)
	// jsonDecoder = json.NewDecoder(bytes.NewReader(file))
	todos := []Todo{}
	jsonDecoder.Decode(&todos)
	resp.Body.Close()

	indexTemplateBytes, err := ioutil.ReadFile("D:/Go_Workspace/src/sandbox/index.html")
	if err != nil {
		return
	}
	indexTemplate := htmlTemplate.Must(htmlTemplate.New("index").Parse(string(indexTemplateBytes)))
	indexTemplate.Execute(os.Stdout, todos)
	fmt.Println()
	// error
	log.SetFlags(0)
	amount, err := withdraw(200)
	if err != nil {
		// fmt.Println(err)
		// return
		log.Fatalf("main: %v", err) // exit program
	}
	fmt.Println("Please collect your money: ", amount)
	// function value
	a, _ := apply(1, 2, add)
	b, _ := apply(1, 2, sub)
	c, _ := apply(1, 2, nil)
	fmt.Println(a, b, c)
	// anonymous function
	f1 := anonymousFunc()
	fmt.Println(f1())
	fmt.Println(f1())
	fmt.Println(f1())
	f2 := anonymousFunc() // f1 and f2 is difference context function
	fmt.Println(f2())
	fmt.Println(f2())
	fmt.Println(f2())

	// funcList := []func(){} // [f1(), f2(), f3()]
	funcList := anonymousFuncList([]int{12, 23, 45, 81})
	for _, v := range funcList {
		v()
	}
	// higher order function and anonymous
	log.SetFlags(0)
	fib := createFib()
	fib = profileTime(fib)
	// fmt.Println(fib(60))
	// fmt.Println(fib(50))
	fib(600000)
	fib(6000)
	// variadic function
	printEachLine("abc", "def", 123, "ghi")
	interfaceList := []interface{}{"xyz", 987, 654}
	printEachLine(interfaceList...)
	// deferred func call
	dfNum := 1
	// addDfNum := func(x int) int {
	// 	dfNum += x
	// 	return dfNum
	// }
	fmt.Println(dfNum)
	// defer fmt.Println(addDfNum(4) + 3)
	// defer fmt.Println(12)
	// fmt.Println(dfNum)
	loadingImage()

	resp, err = http.Get("https://golang.org")
	if err != nil {
		return
	}
	defer resp.Body.Close() // Appropriate used defer for this
	bodyGo, _ := ioutil.ReadAll(resp.Body)
	fmt.Println(string(bodyGo))
	// panic stage & recover
	A(4)
	// OOP (method)
	point := Point{3, 4}
	point.MoveXTo(12)
	fmt.Println(point)

	bt := BinaryTree{ // method with nil receiver
		value: 2,
		left:  &BinaryTree{value: 3, left: &BinaryTree{value: 1, left: nil, right: nil}, right: nil},
		right: &BinaryTree{value: 5},
	}
	fmt.Println(bt)
	fmt.Println(bt.sum())

	peace := Person{"Peace", "Srabour", 33} // embeded struct
	empPeace := Employee{
		Person:   peace,
		Position: "DEV",
	}
	progPeace := Programmer{empPeace, []string{"Java", "C", "Golang"}}
	jugg := Person{"Jugg", "Tanphan", 33}
	empJugg := Employee{jugg, "QA"}
	testJugg := Tester{empJugg, []string{"Robot", "Excel"}}
	fmt.Printf("%+v\n", progPeace)
	fmt.Printf("%+v\n", testJugg)
	fmt.Println(progPeace.IsSamePosition(&(testJugg.Employee)))
	fmt.Println(progPeace.Detail())
	fmt.Println(testJugg.Detail())

	juggDetail := testJugg.Detail // method value
	fmt.Println("Detail: ", juggDetail())
	isSamePosition := (*Employee).IsSamePosition
	fmt.Println(isSamePosition(&empJugg, &empPeace))
	// interface
	nb := NoteBook{}
	fmt.Fprintln(&nb, "Hello world")
	fmt.Println(nb)

	sword := Sword{"Kantana"} // interface satisfaction
	bow := Bow{"Runa"}
	attack(sword)
	attack(bow)

	var weapon Weapon
	weapon = sword
	attack(weapon)
	weapon = bow
	attack(weapon)

	flag.Parse() // flag interface
	fmt.Println(*movieName)
	fmt.Println(movieEpisode)

	plist := []*Person{ // sort with interface
		{Name: "A", Age: 33},
		{Name: "B", Age: 33},
		{Name: "A", Age: 35},
		{Name: "A", Age: 34},
		{Name: "C", Age: 33},
		{Name: "B", Age: 31},
	}
	// sort.Sort(byName(plist))
	sort.Sort(customSort{Persons: plist, less: func(i, j *Person) bool {
		if i.Name != j.Name {
			return i.Name < j.Name
		}
		if i.Age != j.Age {
			return i.Age < j.Age
		}
		return false
	}})
	for _, k := range plist {
		fmt.Println(*k)
	}
}
