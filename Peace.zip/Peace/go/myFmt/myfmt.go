package myFmt

import "fmt"

func Println(s string) {
	fmt.Println("xxx: ", s)
}
