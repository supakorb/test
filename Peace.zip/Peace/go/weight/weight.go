package weight

type KG float64
type LB float64

const kgToLbRatio = 2.204
