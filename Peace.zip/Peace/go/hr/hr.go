package hr

type Person struct {
	Name string
	Age  int
}
type Employee struct {
	Person
	Position string
}
type AisEmployee struct {
	Person
	Position string
}
